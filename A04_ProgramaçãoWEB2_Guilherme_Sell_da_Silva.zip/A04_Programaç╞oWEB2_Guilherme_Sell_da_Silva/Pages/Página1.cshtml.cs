using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace A04_ProgramaçãoWEB2_Guilherme_Sell_da_Silva.Pages
{
    public class Página1Model : PageModel
    {
        public void OnGet()
        {
        }
    }
}
